package com.example.FutbolLigleriBackend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FutbolLigleriBackendApplicationTests {

	@Test
	void contextLoads() {
	}

}
